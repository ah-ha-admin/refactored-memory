const core = require('@actions/core');

core.setOutput('dir-path', __dirname);
