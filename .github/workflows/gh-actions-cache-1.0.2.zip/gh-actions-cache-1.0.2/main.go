package main

import "github.com/actions/gh-actions-cache/cmd"

func main() {
	cmd.Execute()
}
